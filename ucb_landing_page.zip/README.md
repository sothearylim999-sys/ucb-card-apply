# UCB Card Landing Page

## How to Host on GitHub Pages

1. Create a GitHub account
2. Create a new repository
3. Upload `index.html`
4. Go to:
   Settings → Pages
5. Under "Branch":
   select `main`
6. Click Save

Your website will appear like:
https://yourusername.github.io/repository-name/

## Form Setup

Replace this line:

https://formsubmit.co/your@email.com

with your real email.

Example:

https://formsubmit.co/abc@gmail.com

Then submitted forms will go directly to your email.
